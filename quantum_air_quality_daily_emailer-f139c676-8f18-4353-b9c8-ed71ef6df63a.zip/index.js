var AWS = require("aws-sdk");
var https = require('https');
var mysql = require('mysql');
// var nodemailer = require('nodemailer')
var ses = new AWS.SES({region: 'ap-south-1'});
var connection;


exports.handler = (event, context, callback) => {
    
            //console.log("Event",event)

            if(!event.hasOwnProperty("quantum_air_quality_daily_emailer")){
                callback("Valid parameter not found");
                return;
            }
            
            const nowMilliSecs = Date.now();
            console.log('Current timestamp:', nowMilliSecs);
            console.log("Inside Ok")
            
            var mailContent = '';
            
            var subject = 'Problem Detected with quantum_air_quality data:'
                                    
            var emailIDArr = [
            "ruturajraut2000@gmail.com",
            "gautam@claypot.in",
            "chauhan@claypot.in",
            "tech-assist@claypot.in",
            "yogesh@claypot.in"
            
            ];
            const connection = mysql.createConnection({
                host: "claypot-db-instance.ci3ywfy1btrn.ap-south-1.rds.amazonaws.com",
                user: "claypot_db_user",
                password: "claypot_db_user_password",
                database: "claypot_db",
                multipleStatements: true
            })
            
            connection.connect(err => {
                    console.log('in funct')
                    if (err) {
                        console.error('Error conecting to my sql', err)
                        callback('Error connecting to MySQL');
                        return;
                    }
                    //console.log('connection established')
                    });
                    
                    let now = new Date();
                    now.setTime(now.getTime() + (5 * 60 * 60 * 1000) + (30 * 60 * 1000));
                    
                    //console.log(now);
                    
                    // Subtract one day
                    var yesterday = new Date(now);
                    yesterday.setDate(now.getDate() - 1);
                    
                     // Define the start and end time of the time window (8:30 am to 6:30 pm) /---
                    var startTime = new Date(yesterday);
                    startTime.setHours(8, 0, 0, 0); // Set to 8:30 am
                    var endTime = new Date(yesterday);
                    endTime.setHours(20, 0, 0, 0); // Set to 8:00 pm  20:00
                    
                    let year = yesterday.getFullYear();
                    let month = yesterday.getMonth() + 1;
                    let day = yesterday.getDate();
                    let hour = yesterday.getHours();
                    
                    if(month < 10){month = "0" + month};
                    if(day < 10){day = "0" + day};
                    if(hour < 10){hour = "0" + hour};
                    
                    
                    
                    console.log("Start Time:", startTime.toISOString());
                    console.log("End Time:", endTime.toISOString());
                    //=====
                    
                    console.log("Yesterday :", yesterday)
                    // Format yesterday's date as YYYY-MM-DD
                    var yesterdayString = yesterday.toISOString().split('T')[0];
                    
                    console.log("Yesterday Formated",yesterdayString)
                    
                    const dateParts = yesterdayString.split('-'); // Split the date string into year, month, and day
                    
                    // Reformat the date to "dd:mm:yy"
                    const UpdatetedDate = `${dateParts[2]}-${dateParts[1]}-${dateParts[0]}`;
                    
                    console.log(UpdatetedDate); // Output: "dd:mm:yy"
                    
                    //console.log("Date time string:",dateTimeString);
                    
                    
                    
                    var query = `SELECT * FROM claypot_db.active_buildings_data  WHERE device_id = '862174063953814' AND dt = '${yesterdayString}'AND tm >= '08:00:00' 
                    AND tm <= '20:00:00';`;
                    
                    console.log("Query",query);
                        
                
                        
                    //console.log('incallback')
                    connection.query(query, (err, result) => {
                        if (err) {
                            console.error('Error executing query', err)
                            return;
                        } 
                        else {
                            console.log("Hello")
                        // Classify parameters based on thresholds
                        const thresholds = {
                            temperature: {
                                good: 25,
                                moderate: 30,
                                poor: 35
                            },
                            co2: {
                                good: 50,
                                moderate: 60,
                                poor: 70
                            },
                            pm25: {
                                good: 50,
                                moderate: 60,
                                poor: 70
                            },
                            pm10: {
                                good: 50,
                                moderate: 60,
                                poor: 70
                            },
                            tvoc: {
                                good: 50,
                                moderate: 60,
                                poor: 70
                            },
                            humidity:{
                                good:50,
                                poor:70
                            }
                        };
                        
                        console.log("Threshold:",thresholds);
                        
                        
                            //console.log("timeLabelArr:",timeLabelArr)
                        // Iterate through the query result and classify parameters
                        result.forEach(row => {
                    
                            var parameterStatus
                            const temperature = row.temperature;
                            const co2 = row.co2;
                            const pm25 = row.pm25;
                            const pm10 = row.pm10;
                            const tvoc = row.tvoc;
                            const humidity = row.humidity;
                            
                            
                    
                            //console.log("temperature",temperature)
                    
                            // Determine the classification for temperature
                            // Iterate over each parameter
                            if(temperature <= thresholds.temperature.good){
                                parameterStatus = 'good';
                            }
                            else if(temperature>thresholds.temperature.good && temperature<=thresholds.temperature.moderate){
                                parameterStatus = 'moderate';
                            }
                            else if(temperature>thresholds.temperature.moderate && temperature<= thresholds.temperature.poor){
                                parameterStatus = 'poor';
                            }
                            //---
                           // console.log("thresholds.temperature.good",thresholds.temperature.good)
                    
                            if(co2 <= thresholds.co2.good){
                                parameterStatus = 'good';
                            }
                            else if(co2>thresholds.co2.good && co2<=thresholds.co2.moderate){
                                parameterStatus = 'moderate';
                            }
                            else if(co2>thresholds.co2.moderate && co2<= thresholds.co2.poor){
                                parameterStatus = 'poor';
                            }
                            //---
                    
                            if(pm25 <= thresholds.pm25.good){
                                parameterStatus = 'good';
                            }
                            else if(pm25>thresholds.pm25.good && pm25<=thresholds.pm25.moderate){
                                parameterStatus = 'moderate';
                            }
                            else if(pm25>thresholds.pm25.moderate && pm25<= thresholds.pm25.poor){
                                parameterStatus = 'poor';
                            }
                            //---
                    
                            if(pm10 <= thresholds.pm10.good){
                                parameterStatus = 'good';
                            }
                            else if(pm10>thresholds.pm10.good && pm10<=thresholds.pm10.moderate){
                                parameterStatus = 'moderate';
                            }
                            else if(pm10>thresholds.pm10.moderate && pm10<= thresholds.pm10.poor){
                                parameterStatus = 'poor';
                            }
                             //---
                    
                            if(tvoc <= thresholds.tvoc.good){
                                parameterStatus = 'good';
                            }
                            else if(tvoc>thresholds.tvoc.good && tvoc<=thresholds.tvoc.moderate){
                                parameterStatus = 'moderate';
                            }
                            else if(tvoc>thresholds.tvoc.moderate && tvoc<= thresholds.tvoc.poor){
                                parameterStatus = 'poor';
                            }
                            //---
                    
                            if(humidity <= thresholds.humidity.good){
                                parameterStatus = 'good';
                            }
                            else if(humidity>= thresholds.humidity.poor){
                                parameterStatus = 'poor';
                            }
                            
                            console.log("Check 2 ")
                            // Process query result
                            //console.log('Query result:', result);

                            mailContent = `<html><head><style>`;
                            mailContent += `body{background-color:#fff;}`;
                            // mailContent += `#logoImg{width:200px;height:auto;align:center;}`;
                            //mailContent += `h1,h2{color:darkgreen;}`;
                            //mailContent += `#octopus-table{border-radius : 15px;}`;
                            //mailContent += `#octopus-table td{border:1px solid darkgreen;border-collapse: collapse;cellpadding:25;}`;
                            // mailContent += `.tableheader{background-color:orange;color:#fff}`;
                            // mailContent += `#pumpImg,#timeImg,#switchImg{width:40px; height :auto;}`;
                            //mailContent += `.pumpName{font-size:1.2em;color:darkgreen}`;
                            //mailContent += `.pumpRunTime{font-weight:bold;font-size:1.1em;color:darkgreen}`;
                            // mailContent += `.pumpSwitchedOnNum{font-weight:bold;font-size:2em;color:darkgreen}`;
                            // mailContent += `.calendarImg{height:15px;width:auto;}`
                            // mailContent += `.dayheader{background-color:darkgreen;color:#fff;}`;
                            // mailContent += `.smallText{font-size:.9em}`;
                            // mailContent += `#kidsImg{width:300px;height:auto;align:center;}`;
                            // mailContent += `.lighText{color:grey}`;
                            mailContent += `</style></head><body>`;
                            
                            
                            mailContent += `<h2 style="color:darkgreen">Quantum Air Quality Analytics for ${UpdatetedDate}</h2>`;
                            
                            mailContent += `
                            <table id="octopus-table" cellspacing=0 cellpadding=15 style="border-radius:15px">
                            <tr>
                            
                            <td>
                                <table>
                                <tr><td style="background-color:green;width:20px;"></td><td>  Good</td></tr>
                                <tr><td style="background-color:orange;width:20px;"></td><td>  Moderate</td></tr>
                                <tr><td style="background-color:red;width:20px;"></td><td>  Poor</td></tr>
                                </table>
                            </td>
                            </table>
                            <br><br>
                            `;
                            
                            mailContent += `<table id="octopus-table" cellspacing=0 cellpadding=15 style="border-radius:15px">`;
                            mailContent += `<tr style="background-color:black;color:#fff" class='tableheader'>`;
                            mailContent += `<th>TIME</th>`;
                            mailContent += `<th>temperature<br> °C</th>`;
                            mailContent += `<th>Humidity<br>RH </th>`;
                            mailContent += `<th>CO2<br>PPM </th>`;
                            mailContent += `<th>PM2.5<br>µg/m³ </th>`;
                            mailContent += `<th>PM 10<br>µg/m³ </th>`;
                            mailContent += `<th>TVOC<br>PPM</th>`;
                            mailContent += `</tr>`;
                            
    
                            
                            
            
                            result.forEach(x => {
                                
                                    // Assuming x.tm is in the format "hh:mm:ss"
                                    const timeParts = x.tm.split(':'); // Split the time string into hours, minutes, and seconds
                                    const hours = parseInt(timeParts[0]); // Extract hours
                                    const minutes = parseInt(timeParts[1]); // Extract minutes
                                    
                                    // Format hours to include AM/PM
                                    const period = hours >= 12 ? 'PM' : 'AM';
                                    const formattedHours = hours % 12 || 12; // Convert to 12-hour format
                                    
                                    // Construct the formatted time string
                                    const formattedTime = `${formattedHours}:${minutes < 10 ? '0' : ''}${minutes} ${period}`;
                                    
                                    
                                    console.log("Record:",formattedTime)
                                    mailContent += '<tr>';
                                    mailContent += `<td style="background-color:black;color:#fff"><b>${formattedTime}</b></td>`;
                                    
                                    
                                    
                                    const temp_ = x.temperature
                                    const humidity_ = x.humidity
                                    const co2_ = x.co2
                                    const pm25_ = x.pm25
                                    const pm10_ = x.pm10
                                    const tvoc_ = x.tvoc
                                    
                                    
                                    var style = '';
                            
                                    if(temp_ <= 26){style='background-color:green;color:#fff'}
                                    else if(temp_ > 26 && temp_ <= 30){style='background-color:orange;color:#fff'}
                                    else if(temp_ > 30){style='background-color:red;color:#fff'}
                                    
                                    mailContent += `<td style=${style}>`;
                                    mailContent += temp_;
                                    mailContent += '</td>';
                                    
                                    
                                    if(humidity_ <= 30){style='background-color:red;color:#fff'}
                                    else if(humidity_ > 30 && humidity_ <= 80){style='background-color:green;color:#fff'}
                                    else if(humidity_ > 80){style='background-color:red;color:#fff'}
                                    
                                    mailContent += `<td style=${style}>`;
                                    mailContent += humidity_;
                                    mailContent += '</td>';
                                    
                                    if(co2_ <= 700){style='background-color:green;color:#fff'}
                                    else if(co2_ > 700 && co2_ <= 1050){style='background-color:orange;color:#fff'}
                                    else if(co2_ > 1050){style='background-color:red;color:#fff'}
                                    
                                    mailContent += `<td style=${style}>`;
                                    mailContent += co2_;
                                    mailContent += '</td>';
                                    
                                    if(pm25_ <= 15){style='background-color:green;color:#fff'}
                                    else if(pm25_ > 15 && pm25_ <= 100){style='background-color:orange;color:#fff'}
                                    else if(pm25_ > 100){style='background-color:red;color:#fff'}
                                    
                                    mailContent += `<td style=${style}>`;
                                    mailContent += pm25_;
                                    mailContent += '</td>';
                                    
                                    if(pm10_ <= 50){style='background-color:green;color:#fff'}
                                    else if(pm10_ > 50 && pm10_ <= 100){style='background-color:orange;color:#fff'}
                                    else if(pm10_ > 100){style='background-color:red;color:#fff'}
                                    
                                    mailContent += `<td style=${style}>`;
                                    mailContent += pm10_;
                                    mailContent += '</td>';
                                    
                                    if(tvoc_ <= 225){style='background-color:green;color:#fff'}
                                    else if(tvoc_ > 225 && tvoc_ <= 2000){style='background-color:orange;color:#fff'}
                                    else if(tvoc_ > 2000){style='background-color:red;color:#fff'}
                                    
                                    mailContent += `<td style=${style}>`;
                                    mailContent += tvoc_;
                                    mailContent += '</td>';
                                    
                                    mailContent += '</tr>';
            
       
                            });  // result.forEach loop
            
                       
            
                            mailContent += '</table>';
                            
                            
                            mailContent += `<br/><br/><img id="kidsImg" style="width:300px;height:auto;align:center;" src="https://www.octopus-automation.com/apps/eqi/images/kids.png"/>`;
                            mailContent += `&nbsp; &nbsp; <img id="logoImg" src="https://www.octopus-automation.com/apps/eqi/images/octopus-logo-dark-hoh.png" style="width:150px;height:auto;align:center;"/>`;
                            mailContent += `<h5>"CLEANER ENVIRONMENT FOR FUTURE GENERATIONS"</h5>`;
                            mailContent += `<span class="smallText lighText" style="font-size:.9em;color:grey;">This is an automated email from the Octopus system. Please donot reply to this email</span>`;
                            mailContent += `</body></html>`
                                    
                                  
                            console.log("MailContent",mailContent)        

                        })
                            
                                sendMail(emailIDArr, `AI Alerts : Quantum Air Quality Analytics for ${yesterdayString}`, mailContent, (err, data) => {
                                    if (err) {
                                        console.error("Error sending email", err);
                                        callback("Error sending email");
                                    } else {
                                        console.log("Mail sent successfully");
                                        callback(null, "Mail sent successfully");
                                    }
                                    connection.end(); // Close connection after sending mail
                                })
                          
                           //connection.end() 
                        }
                        
                     
                    })
                
                        
}

         // Assuming you have a sendMail function defined
 async function sendMail(emailIDArr, subject, mailContent, callback) {
    // Construct email parameters
    var params = {
        Destination: {
            ToAddresses: emailIDArr
        },
        Message: {
            Body: {
                Html: {
                    Charset: "UTF-8",
                    Data: mailContent
                }
            },
            Subject: {
                Charset: "UTF-8",
                Data: subject
            }
        },
        Source: "octopus-alerts@octopusio.io" 
    };
    
 
    
     // Send the email
    ses.sendEmail(params, function (err, data) {
        if (err) {
            console.error('Error sending email', err);
            callback("Error sending email");
        } else {
            console.log('Email sent successfully', data);
            callback(null, "Mail sent successfully");
        }
    });               
 }                        

                      